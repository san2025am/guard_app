import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'theme.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/forgot_password_screen.dart';
import 'screens/reset_password_screen.dart';
import 'screens/home_guard.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const SanamApp());
}

class SanamApp extends StatelessWidget {
  const SanamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'سنام الأمن',
      debugShowCheckedModeBanner: false,

      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: ThemeMode.system,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const SplashScreen(),
      routes: {
        LoginScreen.route: (_) => const LoginScreen(),
        ForgotPasswordScreen.route: (_) => const ForgotPasswordScreen(),
        ResetPasswordScreen.route: (_) => const ResetPasswordScreen(),
        HomeGuard.route: (_) => const HomeGuard(),
      },
    );
  }
}
