// lib/services/api.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:shared_preferences/shared_preferences.dart';

// لو عندك موديل EmployeeMe جاهز:
import '../models/employee.dart'; // يجب أن يحتوي EmployeeMe.fromJson(Map<String,dynamic>)

// --------------------------------------------------------
// ضبط عنوان الـ API الأساسي (بدون شرطة مائلة في النهاية)
// --------------------------------------------------------
const String kBaseUrl = "http://31.97.158.157/api/v1";

// مسارات جاهزة (لمنع الأخطاء المطبعية):
const String _pLogin           = '/auth/guard/login/';
const String _pMeGet           = '/auth/guard/me/';
const String _pMePost          = '/auth/guard/me/'; // إن كانت POST عندك
const String _pForgotUsername  = '/auth/password/forgot/username/';
const String _pResetBySession  = '/auth/password/reset/username/';
const String _pResolveLocation = '/attendance/resolve-location/';
const String _pAttendanceCheck = '/attendance/check/';

// --------- جديد لبطاقة "آخر تحديث" ---------
const String _pAttendanceLast   = '/attendance/last/';
const String _pAttendanceExists = '/attendance/exists/';

const String _pGuardReports    = '/guards/reports/';
const String _pGuardRequests   = '/guards/requests/';
const String _pGuardAdvances   = '/guards/advances/';
const String _pGuardTasks      = '/guards/tasks/';
const String _pUniformItems    = '/guards/uniform-items/';

// ========================================================
// مُساعِدات عامة
// ========================================================

String _joinUrl(String base, String path) {
  base = base.trim();
  if (base.endsWith('/')) base = base.substring(0, base.length - 1);
  if (!path.startsWith('/')) path = '/$path';
  return '$base$path';
}

Uri _u(String path) => Uri.parse(_joinUrl(kBaseUrl, path));

/// رؤوس JSON الافتراضية المرسلة لكل طلب.
Map<String, String> _jsonHeaders() => const {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
};

dynamic _tryDecode(String text) {
  try { return jsonDecode(text); } catch (_) { return null; }
}

/// فك الاستجابة مع دعم UTF-8
dynamic _decode(http.Response res) {
  final text = utf8.decode(res.bodyBytes);
  final obj  = _tryDecode(text);
  return obj ?? text;
}

/// يستخرج رسالة خطأ صديقة
String _messageFromBody(dynamic body, String fallback) {
  if (body is Map) {
    final map = body as Map;
    for (final key in ['detail', 'message', 'error']) {
      final value = map[key];
      if (value != null && value.toString().trim().isNotEmpty) {
        return value.toString();
      }
    }
    for (final entry in map.entries) {
      final v = entry.value;
      if (v is List && v.isNotEmpty) return v.first.toString();
      if (v is String && v.trim().isNotEmpty) return v;
    }
  } else if (body is List && body.isNotEmpty) {
    return body.first.toString();
  } else if (body is String) {
    final t = body.trim();
    if (t.isEmpty) return fallback;
    final l = t.toLowerCase();
    if (l.startsWith('<!doctype') || l.contains('<html')) return fallback;
    return t;
  }
  return fallback;
}

String _dateOnly(DateTime date) => date.toIso8601String().split('T').first;

Map<String, dynamic> _stringMap(Map source) =>
    source.map((k, v) => MapEntry(k.toString(), v));

/// يمثل مرفقًا ينتظر الرفع
class ReportAttachmentUpload {
  ReportAttachmentUpload({
    required this.file,
    this.contentType,
  });

  final File file;
  final String? contentType;

  MediaType? get mediaType {
    if (contentType == null || contentType!.trim().isEmpty) return null;
    try { return MediaType.parse(contentType!); } catch (_) { return null; }
  }
}

/// يضمن بادئة Bearer
String authHeader(String tokenOrHeader) {
  final t = tokenOrHeader.trim();
  if (t.startsWith('Bearer ') || t.startsWith('Token ')) return t;
  return 'Bearer $t';
}

double? asDouble(dynamic v) {
  if (v == null) return null;
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v.trim());
  return null;
}

int? asInt(dynamic v) {
  if (v == null) return null;
  if (v is num) return v.toInt();
  if (v is String) return int.tryParse(v.trim());
  return null;
}

// ========================================================
// مفاتيح التخزين + التوكن
// ========================================================

const _kAccessKeyNew = 'access_token';
const _kAccessKeyOld = 'access';      // توافق خلفي
const _kRefreshKey  = 'refresh_token';
const _kEmpKey      = 'employee_json';

// --------- جديد (اختياري): تخزين آخر سجل محليًا لعرضه فورًا ----------
const _kLastRecord = 'last_attendance_json';

Future<void> _saveTokensRaw({required String access, String? refresh}) async {
  final sp = await SharedPreferences.getInstance();
  await sp.setString(_kAccessKeyNew, access);
  if (refresh != null && refresh.isNotEmpty) {
    await sp.setString(_kRefreshKey, refresh);
  }
  await sp.remove(_kAccessKeyOld);
}

Future<String?> _getAccessRaw() async {
  final sp = await SharedPreferences.getInstance();
  var acc = sp.getString(_kAccessKeyNew) ?? sp.getString(_kAccessKeyOld);
  if (acc == null || acc.isEmpty) return null;
  if (acc.startsWith('Bearer ')) acc = acc.substring(7);
  await sp.setString(_kAccessKeyNew, acc);
  await sp.remove(_kAccessKeyOld);
  return acc;
}

// ========================================================
// نتائج موحدة
// ========================================================

typedef ApiResult   = ({bool ok, String message, Map<String, dynamic>? data});
typedef LoginResult = ({bool ok, String message, EmployeeMe? employee, Map<String, dynamic>? raw});

// ========================================================
// خدمة الـ API
// ========================================================

class ApiService {
  static final http.Client _client = http.Client();
  static Future<String?> getAccessToken() => _getAccessRaw();
  static Future<EmployeeMe?> getCachedEmployee() => cachedEmployee();

  // ---------------------------------------------
  // Login
  // ---------------------------------------------
  static Future<Map<String, dynamic>> guardLogin(
      String username,
      String password, {
        required String deviceId,
        required String deviceName,
        String? challengeId,
        String? otpCode,
      }) async {
    try {
      final payload = <String, dynamic>{
        'username': username,
        'password': password,
        'device_id': deviceId,
        'device_name': deviceName,
      };
      if (challengeId != null && challengeId.isNotEmpty) {
        payload['challenge_id'] = challengeId;
      }
      if (otpCode != null && otpCode.isNotEmpty) {
        payload['otp_code'] = otpCode;
      }

      final res = await _client.post(
        _u(_pLogin),
        headers: _jsonHeaders(),
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);

      if (res.statusCode == 200 && body is Map<String, dynamic>) {
        final prefs = await SharedPreferences.getInstance();

        final access  = (body['access'] ?? body['token'])?.toString() ?? '';
        final refresh = (body['refresh'] ?? '').toString();
        if (access.isEmpty) {
          return {'ok': false, 'message': 'لم يستلم التطبيق رمز الدخول (access token).'};
        }
        await _saveTokensRaw(access: access, refresh: refresh);

        final user = (body['user'] is Map) ? body['user'] as Map : <String, dynamic>{};
        await prefs.setString('username', (user['username'] ?? '').toString());
        final roleVal  = user['role'];
        final roleText = (roleVal is Map)
            ? (roleVal['name'] ?? roleVal['title'] ?? roleVal.toString()).toString()
            : (roleVal?.toString() ?? '');
        await prefs.setString('role', roleText);

        Map<String, dynamic>? empJson;
        if (body.containsKey('employee') && body['employee'] is Map) {
          empJson = Map<String, dynamic>.from(body['employee'] as Map);
          await prefs.setString(_kEmpKey, jsonEncode(empJson));
        }

        EmployeeMe? empModel;
        if (empJson != null) {
          try { empModel = EmployeeMe.fromJson(empJson); } catch (_) { empModel = null; }
        }

        return {'ok': true, 'employee': empModel};
      }

      if (res.statusCode == 202 && body is Map<String, dynamic>) {
        return {
          'ok': false,
          'requires_verification': true,
          'challenge_id': body['challenge_id']?.toString(),
          'message': (body['detail'] ?? 'يتطلب توثيق الجهاز').toString(),
          'destination': body['destination']?.toString(),
          'delivery': body['delivery']?.toString(),
          'debug_code': body['debug_code']?.toString(),
        };
      }

      if (body is Map<String, dynamic>) {
        final map = <String, dynamic>{
          'ok': false,
          'message': (body['detail'] ?? body['message'] ?? 'تعذّر تسجيل الدخول').toString(),
        };
        if (body['code'] != null) map['code'] = body['code'];
        if (body['requires_verification'] == true) {
          map['requires_verification'] = true;
          map['challenge_id'] = body['challenge_id']?.toString();
        }
        return map;
      }

      return {'ok': false, 'message': "الخادم أعاد محتوى غير متوقع (رمز ${res.statusCode})."};
    } catch (e) {
      return {'ok': false, 'message': 'خطأ في الشبكة: $e'};
    }
  }

  // ---------------------------------------------
  // ME
  // ---------------------------------------------
  static Future<EmployeeMe?> fetchEmployeeAndCache() async {
    final prefs = await SharedPreferences.getInstance();
    final accessRaw = await _getAccessRaw();
    if (accessRaw == null || accessRaw.isEmpty) return null;

    try {
      final res = await _client.get(
        _u(_pMeGet),
        headers: {
          ..._jsonHeaders(),
          'Authorization': authHeader(accessRaw),
        },
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);
      if (res.statusCode == 200) {
        final emp = (body is Map && body.containsKey('employee')) ? body['employee'] : body;
        if (emp is Map<String, dynamic>) {
          await prefs.setString(_kEmpKey, jsonEncode(emp));
          try { return EmployeeMe.fromJson(emp); } catch (_) { return null; }
        }
      } else {
        debugPrint('fetchEmployeeAndCache ${res.statusCode} -> $body');
      }
    } catch (e) {
      debugPrint('fetchEmployeeAndCache error: $e');
    }
    return null;
  }

  static Future<EmployeeMe?> cachedEmployee() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kEmpKey);
    if (raw == null || raw.isEmpty) return null;
    try {
      final map = jsonDecode(raw);
      if (map is Map<String, dynamic>) return EmployeeMe.fromJson(map);
    } catch (_) {}
    return null;
  }

  static Future<EmployeeMe?> ensureEmployeeCached() async {
    final cached = await cachedEmployee();
    if (cached != null) return cached;
    return await fetchEmployeeAndCache();
  }

  static Future<EmployeeMe?> refreshEmployeeCache() async {
    final prefs = await SharedPreferences.getInstance();
    final accessRaw = await _getAccessRaw();
    if (accessRaw == null || accessRaw.isEmpty) return null;

    final res = await _client.post(
      _u(_pMePost),
      headers: {
        ..._jsonHeaders(),
        'Authorization': authHeader(accessRaw),
      },
      body: '{}',
    ).timeout(const Duration(seconds: 20));

    final body = _decode(res);
    if (res.statusCode == 200) {
      final emp = (body is Map && body.containsKey('employee')) ? body['employee'] : body;
      if (emp is Map<String, dynamic>) {
        await prefs.setString(_kEmpKey, jsonEncode(emp));
        try { return EmployeeMe.fromJson(emp); } catch (_) { return null; }
      }
    }
    return null;
  }

  static Future<void> logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_kAccessKeyNew);
    await p.remove(_kAccessKeyOld);
    await p.remove(_kRefreshKey);
    await p.remove(_kEmpKey);
    await p.remove(_kLastRecord); // جديد: نظّف آخر سجل
    await p.remove('username');
    await p.remove('role');
  }

  // ---------------------------------------------
  // نسيت كلمة المرور
  // ---------------------------------------------
  static Future<Map<String, dynamic>> forgotByUsername(String username) async {
    try {
      final res = await _client.post(
        _u(_pForgotUsername),
        headers: _jsonHeaders(),
        body: jsonEncode({'username': username}),
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);
      if (res.statusCode == 200 && body is Map<String, dynamic>) {
        return {'ok': true, 'session_id': body['session_id'], 'detail': body['detail']};
      }
      return {'ok': false, 'message': (body is Map && body['detail'] != null) ? body['detail'].toString() : 'تعذر إرسال الكود'};
    } catch (e) {
      return {'ok': false, 'message': 'خطأ في الشبكة: $e'};
    }
  }

  static Future<Map<String, dynamic>> resetBySession({
    required int sessionId,
    required String code,
    required String newPassword,
  }) async {
    try {
      final res = await _client.post(
        _u(_pResetBySession),
        headers: _jsonHeaders(),
        body: jsonEncode({
          'session_id': sessionId,
          'code': code,
          'new_password': newPassword,
        }),
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);
      if (res.statusCode == 200 && body is Map<String, dynamic>) {
        return {'ok': true, 'detail': body['detail']};
      }
      return {'ok': false, 'message': (body is Map && body['detail'] != null) ? body['detail'].toString() : 'فشل التحقق من الرمز'};
    } catch (e) {
      return {'ok': false, 'message': 'خطأ في الشبكة: $e'};
    }
  }

  // ---------------------------------------------
  // جديد: آخر سجل + التحقق من وجوده
  // ---------------------------------------------

  /// يجلب آخر سجل حضور/انصراف من السيرفر.
  /// يتوقع رد مثل:
  /// { id, employee_id, check_in_time, check_out_time, early_checkout, location_id, location_name, updated_at }
  static Future<Map<String, dynamic>?> fetchLastAttendance() async {
    final token = await _getAccessRaw();
    if (token == null || token.isEmpty) return null;

    final res = await _client.get(
      _u(_pAttendanceLast),
      headers: {
        ..._jsonHeaders(),
        'Authorization': authHeader(token),
      },
    ).timeout(const Duration(seconds: 20));

    if (res.statusCode == 204) return null;
    final body = _decode(res);
    if (res.statusCode == 200 && body is Map<String, dynamic>) {
      // خزّن نسخة محلية اختيارية لعرضها فور فتح الصفحة
      final sp = await SharedPreferences.getInstance();
      await sp.setString(_kLastRecord, jsonEncode(body));
      return body;
    }
    return null;
  }

  /// يتحقق إن كان سجل الحضور ما زال موجودًا (يرجع false إذا حُذف من السيرفر).
  /// السيرفر المثالي يعيد 204 لو موجود، و 404 لو غير موجود.
  static Future<bool> attendanceExists(String recordId) async {
    final token = await _getAccessRaw();
    if (token == null || token.isEmpty) return false;

    final uri = Uri.parse('${_joinUrl(kBaseUrl, _pAttendanceExists)}$recordId/');
    final res = await _client.get(
      uri,
      headers: {
        ..._jsonHeaders(),
        'Authorization': authHeader(token),
      },
    ).timeout(const Duration(seconds: 15));

    if (res.statusCode == 204) return true;
    if (res.statusCode == 404) {
      // نظّف الكاش المحلي إن كان يحمل نفس الـ id
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString(_kLastRecord);
      if (raw != null) {
        try {
          final m = jsonDecode(raw);
          if (m is Map && (m['id']?.toString() == recordId)) {
            await sp.remove(_kLastRecord);
          }
        } catch (_) {}
      }
      return false;
    }
    // أي رمز آخر: لا نغيّر شيء
    return true;
  }

  /// يقرأ آخر سجل من الكاش (إن وُجد) لعرضه مباشرة قبل الاستعلام من الشبكة.
  static Future<Map<String, dynamic>?> cachedLastAttendance() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString(_kLastRecord);
    if (raw == null || raw.isEmpty) return null;
    try {
      final m = jsonDecode(raw);
      return (m is Map<String, dynamic>) ? m : null;
    } catch (_) {
      return null;
    }
  }

  // ---------------------------------------------
  // التقارير / الطلبات / السلف / المهام / الزي
  // ---------------------------------------------

  static Future<ApiResult> submitGuardReport({
    required String reportType,
    required String description,
    String? locationId,
    List<ReportAttachmentUpload> attachments = const [],
  }) async {
    final token = await _getAccessRaw();
    if (token == null || token.isEmpty) {
      return (ok: false, message: 'يرجى تسجيل الدخول مجددًا.', data: null);
    }

    try {
      http.Response res;
      final usableAttachments = attachments
          .where((att) => att.file.existsSync())
          .toList(growable: false);

      if (usableAttachments.isEmpty) {
        res = await _client.post(
          _u(_pGuardReports),
          headers: {
            ..._jsonHeaders(),
            'Authorization': authHeader(token),
          },
          body: jsonEncode({
            'report_type': reportType,
            'description': description,
            if (locationId != null && locationId.isNotEmpty) 'location': locationId,
          }),
        ).timeout(const Duration(seconds: 20));
      } else {
        final req = http.MultipartRequest('POST', _u(_pGuardReports));
        req.headers.addAll({
          'Authorization': authHeader(token),
          'Accept': 'application/json',
        });
        req.fields['report_type'] = reportType;
        req.fields['description'] = description;
        if (locationId != null && locationId.isNotEmpty) {
          req.fields['location'] = locationId;
        }
        for (final att in usableAttachments) {
          req.files.add(await http.MultipartFile.fromPath(
            'attachments',
            att.file.path,
            contentType: att.mediaType,
          ));
        }
        final streamed = await req.send().timeout(const Duration(seconds: 30));
        res = await http.Response.fromStream(streamed);
      }

      final body = _decode(res);
      if (res.statusCode == 200 || res.statusCode == 201) {
        final data = body is Map<String, dynamic>
            ? Map<String, dynamic>.from(body)
            : {'raw': body};
        return (ok: true, message: 'ok', data: data);
      }

      if (res.statusCode == 404) {
        return (
          ok: false,
          message: 'واجهة التقارير غير متاحة (404).',
          data: body is Map<String, dynamic> ? Map<String, dynamic>.from(body) : null,
        );
      }

      final message = _messageFromBody(body, 'تعذّر إرسال التقرير. تحقق من البيانات المدخلة.');
      final data = body is Map<String, dynamic>
          ? Map<String, dynamic>.from(body)
          : (body is Map ? _stringMap(body as Map) : null);
      return (ok: false, message: message, data: data);
    } catch (e) {
      return (ok: false, message: 'خطأ في الشبكة: $e', data: null);
    }
  }

  static Future<ApiResult> submitGuardRequest({
    required String requestType,
    required String description,
    DateTime? leaveStart,
    DateTime? leaveEnd,
    List<Map<String, dynamic>>? uniformItems,
    String? paymentMethod,
    String? uniformLocationId,
  }) async {
    final token = await _getAccessRaw();
    if (token == null || token.isEmpty) {
      return (ok: false, message: 'يرجى تسجيل الدخول مجددًا.', data: null);
    }

    final payload = <String, dynamic>{
      'request_type': requestType,
      'description': description,
    };

    if (requestType == 'leave') {
      if (leaveStart != null) payload['leave_start'] = leaveStart.toIso8601String();
      if (leaveEnd != null) payload['leave_end'] = leaveEnd.toIso8601String();
    }

    if (requestType == 'uniform') {
      if (uniformItems != null && uniformItems.isNotEmpty) {
        payload['uniform_items'] = uniformItems;
      }
      if (paymentMethod != null && paymentMethod.trim().isNotEmpty) {
        payload['payment_method'] = paymentMethod.trim();
      }
      if (uniformLocationId != null && uniformLocationId.trim().isNotEmpty) {
        payload['uniform_location_id'] = uniformLocationId.trim();
      }
    }

    try {
      final res = await _client.post(
        _u(_pGuardRequests),
        headers: {
          ..._jsonHeaders(),
          'Authorization': authHeader(token),
        },
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);
      if (res.statusCode == 200 || res.statusCode == 201) {
        final data = body is Map<String, dynamic>
            ? Map<String, dynamic>.from(body)
            : {'raw': body};
        return (ok: true, message: 'ok', data: data);
      }

      if (res.statusCode == 404) {
        return (
          ok: false,
          message: 'واجهة الطلبات غير متاحة (404).',
          data: body is Map<String, dynamic> ? Map<String, dynamic>.from(body) : null,
        );
      }

      final message = _messageFromBody(body, 'تعذّر إرسال الطلب. تحقق من البيانات المدخلة.');
      final data = body is Map<String, dynamic>
          ? Map<String, dynamic>.from(body)
          : (body is Map ? _stringMap(body as Map) : null);
      return (ok: false, message: message, data: data);
    } catch (e) {
      return (ok: false, message: 'خطأ في الشبكة: $e', data: null);
    }
  }

  static Future<ApiResult> submitGuardAdvance({
    required double amount,
    String? reason,
  }) async {
    final token = await _getAccessRaw();
    if (token == null || token.isEmpty) {
      return (ok: false, message: 'يرجى تسجيل الدخول مجددًا.', data: null);
    }

    final payload = {
      'amount': amount,
      if (reason != null && reason.trim().isNotEmpty) 'reason': reason.trim(),
    };

    try {
      final res = await _client.post(
        _u(_pGuardAdvances),
        headers: {
          ..._jsonHeaders(),
          'Authorization': authHeader(token),
        },
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);
      if (res.statusCode == 200 || res.statusCode == 201) {
        final data = body is Map<String, dynamic>
            ? Map<String, dynamic>.from(body)
            : {'raw': body};
        return (ok: true, message: 'ok', data: data);
      }

      if (res.statusCode == 404) {
        return (
          ok: false,
          message: 'واجهة السلف غير متاحة (404).',
          data: body is Map<String, dynamic> ? Map<String, dynamic>.from(body) : null,
        );
      }

      final message = _messageFromBody(body, 'تعذّر إرسال طلب السلفة. تحقق من البيانات المدخلة.');
      final data = body is Map<String, dynamic>
          ? Map<String, dynamic>.from(body)
          : (body is Map ? _stringMap(body as Map) : null);
      return (ok: false, message: message, data: data);
    } catch (e) {
      return (ok: false, message: 'خطأ في الشبكة: $e', data: null);
    }
  }

  static Future<ApiResult> fetchGuardAdvances() async {
    final token = await _getAccessRaw();
    if (token == null || token.isEmpty) {
      return (ok: false, message: 'يرجى تسجيل الدخول مجددًا.', data: null);
    }

    try {
      final res = await _client.get(
        _u(_pGuardAdvances),
        headers: {
          ..._jsonHeaders(),
          'Authorization': authHeader(token),
        },
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);
      if (res.statusCode == 200) {
        List<dynamic> results = const [];
        if (body is List) {
          results = List<dynamic>.from(body);
        } else if (body is Map && body['results'] is List) {
          results = List<dynamic>.from(body['results'] as List);
        }
        final data = <String, dynamic>{'results': results, 'raw': body};
        return (ok: true, message: 'ok', data: data);
      }

      if (res.statusCode == 404) {
        return (
          ok: false,
          message: 'واجهة السلف غير متاحة (404).',
          data: body is Map<String, dynamic> ? Map<String, dynamic>.from(body) : null,
        );
      }

      final message = _messageFromBody(body, 'تعذّر تحميل السلف');
      final data = body is Map<String, dynamic>
          ? Map<String, dynamic>.from(body)
          : (body is Map ? _stringMap(body as Map) : null);
      return (ok: false, message: message, data: data);
    } catch (e) {
      return (ok: false, message: 'خطأ في الشبكة: $e', data: null);
    }
  }

  static Future<ApiResult> fetchGuardRequests({bool includeClosed = false}) async {
    final token = await _getAccessRaw();
    if (token == null || token.isEmpty) {
      return (ok: false, message: 'يرجى تسجيل الدخول مجددًا.', data: null);
    }

    final basePath = _joinUrl(kBaseUrl, _pGuardRequests);
    final uri = includeClosed
        ? Uri.parse('$basePath?include_closed=true')
        : Uri.parse(basePath);

    try {
      final res = await _client.get(
        uri,
        headers: {
          ..._jsonHeaders(),
          'Authorization': authHeader(token),
        },
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);
      if (res.statusCode == 200) {
        List<dynamic> results = const [];
        if (body is List) {
          results = List<dynamic>.from(body);
        } else if (body is Map && body['results'] is List) {
          results = List<dynamic>.from(body['results'] as List);
        }
        final data = <String, dynamic>{'results': results, 'raw': body};
        return (ok: true, message: 'ok', data: data);
      }

      if (res.statusCode == 404) {
        return (
          ok: false,
          message: 'واجهة الطلبات غير متاحة (404).',
          data: body is Map<String, dynamic> ? Map<String, dynamic>.from(body) : null,
        );
      }

      final message = _messageFromBody(body, 'تعذّر تحميل الطلبات');
      final data = body is Map<String, dynamic>
          ? Map<String, dynamic>.from(body)
          : (body is Map ? _stringMap(body as Map) : null);
      return (ok: false, message: message, data: data);
    } catch (e) {
      return (ok: false, message: 'خطأ في الشبكة: $e', data: null);
    }
  }

  static Future<ApiResult> fetchGuardTasks({String? statusFilter}) async {
    final token = await _getAccessRaw();
    if (token == null || token.isEmpty) {
      return (ok: false, message: 'يرجى تسجيل الدخول مجددًا.', data: null);
    }

    Uri uri = _u(_pGuardTasks);
    if (statusFilter != null && statusFilter.trim().isNotEmpty) {
      final current = Map<String, String>.from(uri.queryParameters);
      current['status'] = statusFilter.trim();
      uri = uri.replace(queryParameters: current);
    }

    try {
      final res = await _client.get(
        uri,
        headers: {
          ..._jsonHeaders(),
          'Authorization': authHeader(token),
        },
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);
      if (res.statusCode == 200) {
        final List<dynamic> rawList;
        if (body is List) {
          rawList = List<dynamic>.from(body);
        } else if (body is Map && body['results'] is List) {
          rawList = List<dynamic>.from(body['results'] as List);
        } else {
          rawList = const [];
        }

        final results = rawList
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(growable: false);

        return (ok: true, message: 'ok', data: {'results': results});
      }

      final message = _messageFromBody(body, 'تعذّر تحميل المهام.');
      final data = body is Map<String, dynamic> ? Map<String, dynamic>.from(body) : null;
      return (ok: false, message: message, data: data);
    } catch (e) {
      return (ok: false, message: 'خطأ في الشبكة: $e', data: null);
    }
  }

  static Future<ApiResult> updateGuardTask({
    required String taskId,
    required String status,
    String? statusNote,
  }) async {
    final token = await _getAccessRaw();
    if (token == null || token.isEmpty) {
      return (ok: false, message: 'يرجى تسجيل الدخول مجددًا.', data: null);
    }

    final payload = <String, dynamic>{
      'status': status,
      if (statusNote != null) 'status_note': statusNote,
    };

    try {
      final res = await _client.patch(
        Uri.parse('${_joinUrl(kBaseUrl, _pGuardTasks)}$taskId/'),
        headers: {
          ..._jsonHeaders(),
          'Authorization': authHeader(token),
        },
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);
      if (res.statusCode == 200) {
        final data = body is Map<String, dynamic>
            ? Map<String, dynamic>.from(body)
            : (body is Map ? _stringMap(body as Map) : null);
        return (ok: true, message: 'ok', data: data);
      }

      final message = _messageFromBody(body, 'تعذّر تحديث المهمة.');
      final data = body is Map<String, dynamic> ? Map<String, dynamic>.from(body) : null;
      return (ok: false, message: message, data: data);
    } catch (e) {
      return (ok: false, message: 'خطأ في الشبكة: $e', data: null);
    }
  }

  static Future<ApiResult> fetchUniformItems() async {
    final token = await _getAccessRaw();
    if (token == null || token.isEmpty) {
      return (ok: false, message: 'يرجى تسجيل الدخول مجددًا.', data: null);
    }

    try {
      final res = await _client.get(
        _u(_pUniformItems),
        headers: {
          ..._jsonHeaders(),
          'Authorization': authHeader(token),
        },
      ).timeout(const Duration(seconds: 20));

      final body = _decode(res);
      if (res.statusCode == 200) {
        final List<dynamic> rawList;
        if (body is Map && body['results'] is List) {
          rawList = List<dynamic>.from(body['results'] as List);
        } else if (body is List) {
          rawList = List<dynamic>.from(body);
        } else {
          rawList = const [];
        }
        final results = rawList
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(growable: false);
        return (ok: true, message: 'ok', data: {'results': results});
      }

      final message = _messageFromBody(body, 'تعذّر تحميل قائمة الزي.');
      final data = body is Map<String, dynamic> ? Map<String, dynamic>.from(body) : null;
      return (ok: false, message: message, data: data);
    } catch (e) {
      return (ok: false, message: 'خطأ في الشبكة: $e', data: null);
    }
  }
}

// ========================================================
// الموقع والحضور/الانصراف
// ========================================================

Future<void> requestLocationPermissionsOrThrow() async {
  final serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    throw Exception("خدمة الموقع غير مفعّلة. فعّل الـ GPS ثم حاول مرة أخرى.");
  }
  var perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) {
    perm = await Geolocator.requestPermission();
  }
  if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
    throw Exception("تم رفض إذن الوصول للموقع. الرجاء منح الإذن من الإعدادات.");
  }
}

Future<Position> getBestFix({
  Duration window = const Duration(seconds: 8),
  LocationAccuracy accuracy = LocationAccuracy.best,
}) async {
  final serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    throw Exception("خدمة الموقع غير مفعّلة. فعّل GPS وحاول مجددًا.");
  }
  var perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) {
    perm = await Geolocator.requestPermission();
  }
  if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
    throw Exception("تم رفض صلاحية الوصول للموقع. الرجاء منح الإذن.");
  }

  final end = DateTime.now().add(window);
  Position? best;
  while (DateTime.now().isBefore(end)) {
    final pos = await Geolocator.getCurrentPosition(desiredAccuracy: accuracy);
    if (best == null || pos.accuracy < best.accuracy) best = pos;
    if (best.accuracy <= 15) break;
    await Future.delayed(const Duration(milliseconds: 800));
  }
  if (best == null) throw Exception("تعذّر الحصول على إحداثيات.");
  return best;
}

Future<ApiResult> sendAttendance({
  required String baseUrl,
  required String token,
  required dynamic locationId,
  required String action,       // "check_in" | "check_out" | "early_check_out"
  Duration window = const Duration(seconds: 8),
  String? earlyReason,
  File? earlyAttachment,
}) async {
  try {
    final pos = await getBestFix(window: window);
    return await sendAttendanceWithPosition(
      baseUrl: baseUrl,
      token: token,
      locationId: locationId,
      action: action,
      pos: pos,
      earlyReason: earlyReason,
      earlyAttachment: earlyAttachment,
    );
  } catch (e) {
    return (ok: false, message: e.toString(), data: null);
  }
}

Future<ApiResult> sendAttendanceWithPosition({
  required String baseUrl,
  required String token,
  required dynamic locationId,
  required String action,           // check_in | check_out | early_check_out
  required Position pos,
  String? earlyReason,
  File? earlyAttachment,
}) async {
  try {
    final uri = Uri.parse(_joinUrl(baseUrl, _pAttendanceCheck));

    final Map<String, dynamic> body = {
      'location_id': locationId,
      'action': action,
      'lat': pos.latitude,
      'lng': pos.longitude,
      'accuracy': pos.accuracy,
      if (earlyReason != null && earlyReason.isNotEmpty) 'early_reason': earlyReason,
    };

    http.Response res;
    if (earlyAttachment != null) {
      final req = http.MultipartRequest('POST', uri);
      req.headers.addAll({'Authorization': authHeader(token)});
      body.forEach((k, v) => req.fields[k] = v.toString());
      req.files.add(await http.MultipartFile.fromPath('early_attachment', earlyAttachment.path));
      final streamed = await req.send();
      res = await http.Response.fromStream(streamed);
    } else {
      res = await http.post(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': authHeader(token),
        },
        body: jsonEncode(body),
      );
    }

    final text = utf8.decode(res.bodyBytes);
    Map<String, dynamic>? data;
    try { data = jsonDecode(text) as Map<String, dynamic>; } catch (_) {}

    final ok = (res.statusCode == 200 || res.statusCode == 201) && (data?['ok'] ?? true);
    final msg = (data?['detail']?.toString() ?? (ok ? 'تم تنفيذ العملية بنجاح' : 'تعذر تنفيذ الطلب'));

    // لو كان آخر سجل موجود في الرد خله يحدّث الكاش
    if (ok && data != null && data['record_id'] != null) {
      try {
        final sp = await SharedPreferences.getInstance();
        // ليس كل الرد يرسل تفاصيل السجل؛ فقط نحاول مزامنة /attendance/last/ عند أول فرصة
        // هنا لا نفعل شيء إضافي.
        await sp.remove(_kLastRecord);
      } catch (_) {}
    }

    return (ok: ok, message: msg, data: data);
  } catch (e) {
    return (ok: false, message: 'خطأ في الاتصال: $e', data: null);
  }
}

Future<ApiResult> resolveMyLocation({
  required String baseUrl,
  required String token,
  required double lat,
  required double lng,
  required double accuracy,
}) async {
  try {
    final uri = Uri.parse(_joinUrl(baseUrl, _pResolveLocation));
    final res = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': authHeader(token),
      },
      body: jsonEncode({'lat': lat, 'lng': lng, 'accuracy': accuracy}),
    );

    final text = utf8.decode(res.bodyBytes);
    Map<String, dynamic>? data;
    try { data = jsonDecode(text) as Map<String, dynamic>; } catch (_) {}

    final ok  = res.statusCode >= 200 && res.statusCode < 300;
    final msg = data?['detail']?.toString() ?? (ok ? 'تم' : 'تعذر تحديد الموقع');
    return (ok: ok, message: msg, data: data);
  } catch (e) {
    return (ok: false, message: e.toString(), data: null);
  }
}

// ========================================================
// دوال مختصرة تلقائية
// ========================================================

Future<ApiResult> checkInAuto({
  String baseUrl = kBaseUrl,
  required String token,
  Duration fixWindow = const Duration(seconds: 8),
}) async {
  try {
    final pos = await getBestFix(window: fixWindow);
    final r = await resolveMyLocation(
      baseUrl: baseUrl,
      token: token,
      lat: pos.latitude,
      lng: pos.longitude,
      accuracy: pos.accuracy,
    );
    if (!r.ok || r.data?['location_id'] == null) {
      return (ok: false, message: r.message.isNotEmpty ? r.message : 'لا يوجد موقع مكلّف به هنا', data: r.data);
    }
    final lid = r.data!['location_id'].toString();
    final res = await sendAttendanceWithPosition(
      baseUrl: baseUrl,
      token: token,
      locationId: lid,
      action: 'check_in',
      pos: pos,
    );
    return res;
  } catch (e) {
    return (ok: false, message: 'تعذّر إتمام الحضور: $e', data: null);
  }
}

Future<ApiResult> checkOutAuto({
  String baseUrl = kBaseUrl,
  required String token,
  Duration fixWindow = const Duration(seconds: 8),
}) async {
  try {
    final pos = await getBestFix(window: fixWindow);
    final r = await resolveMyLocation(
      baseUrl: baseUrl,
      token: token,
      lat: pos.latitude,
      lng: pos.longitude,
      accuracy: pos.accuracy,
    );
    if (!r.ok || r.data?['location_id'] == null) {
      return (ok: false, message: r.message.isNotEmpty ? r.message : 'لا يوجد موقع مكلّف به هنا', data: r.data);
    }
    final lid = r.data!['location_id'].toString();
    final res = await sendAttendanceWithPosition(
      baseUrl: baseUrl,
      token: token,
      locationId: lid,
      action: 'check_out',
      pos: pos,
    );
    return res;
  } catch (e) {
    return (ok: false, message: 'تعذّر إتمام الانصراف: $e', data: null);
  }
}

Future<ApiResult> earlyCheckOutAuto({
  String baseUrl = kBaseUrl,
  required String token,
  required String reason,
  File? attachment,
  Duration fixWindow = const Duration(seconds: 8),
}) async {
  try {
    final pos = await getBestFix(window: fixWindow);
    final r = await resolveMyLocation(
      baseUrl: baseUrl,
      token: token,
      lat: pos.latitude,
      lng: pos.longitude,
      accuracy: pos.accuracy,
    );
    if (!r.ok || r.data?['location_id'] == null) {
      return (ok: false, message: r.message.isNotEmpty ? r.message : 'لا يوجد موقع مكلّف به هنا', data: r.data);
    }
    final lid = r.data!['location_id'].toString();
    final res = await sendAttendanceWithPosition(
      baseUrl: baseUrl,
      token: token,
      locationId: lid,
      action: 'early_check_out',
      pos: pos,
      earlyReason: reason,
      earlyAttachment: attachment,
    );
    return res;
  } catch (e) {
    return (ok: false, message: 'تعذّر إتمام الانصراف المبكر: $e', data: null);
  }
}
