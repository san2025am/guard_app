import 'package:flutter/material.dart';
import '../services/api.dart';

class ResetPasswordScreen extends StatefulWidget {
  static const route = '/reset';
  const ResetPasswordScreen({super.key});
  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  final _form = GlobalKey<FormState>();
  final _code = TextEditingController();
  final _pass = TextEditingController();
  int? _sessionId;
  bool _loading = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)!.settings.arguments as Map?;
    _sessionId ??= args?['session_id'] as int?;
  }

  @override
  void dispose() { _code.dispose(); _pass.dispose(); super.dispose(); }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (_sessionId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('رقم الجلسة غير موجود')));
      return;
    }
    setState(()=>_loading=true);
    final r = await ApiService.resetBySession(sessionId: _sessionId!, code: _code.text.trim(), newPassword: _pass.text);
    setState(()=>_loading=false);
    if (!mounted) return;
    if (r['ok']==true) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['detail'])));
      Navigator.of(context).popUntil((r)=>r.isFirst);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['message'])));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تأكيد الرمز وتعيين كلمة المرور')),
        body: Padding(
          padding: const EdgeInsets.all(22),
          child: Form(
            key: _form,
            child: Column(
              children: [
                Text('أدخل الرمز الذي وصلك إلى البريد، ثم كلمة المرور الجديدة.\nرقم الجلسة: ${_sessionId ?? "-"}'),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _code,
                  decoration: const InputDecoration(labelText: 'الرمز (6 أرقام)'),
                  keyboardType: TextInputType.number,
                  validator: (v) => (v==null || v.length<4) ? 'رمز غير صحيح' : null,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _pass,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'كلمة المرور الجديدة'),
                  validator: (v) => (v==null || v.length<6) ? 'كلمة المرور قصيرة' : null,
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _loading ? null : _submit,
                    child: _loading ? const CircularProgressIndicator() : const Text('تغيير كلمة المرور'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
