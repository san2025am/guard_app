import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api.dart';
import 'forgot_password_screen.dart';
import 'home_guard.dart';

class LoginScreen extends StatefulWidget {
  static const route = '/login';
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _u = TextEditingController();
  final _p = TextEditingController();
  bool _obscure = true, _loading = false;

  @override
  void dispose() { _u.dispose(); _p.dispose(); super.dispose(); }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);
    final r = await ApiService.guardLogin(_u.text.trim(), _p.text);
    setState(() => _loading = false);
    if (!mounted) return;
    if (r['ok'] == true) {
      final prefs = await SharedPreferences.getInstance();
      final role = (prefs.getString('role') ?? '').toLowerCase();
      // بإمكانك الاعتماد على الـ backend للتحقق من الدور، هنا فقط توجيه بسيط
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل الدخول')));
      Navigator.of(context).pushReplacementNamed(HomeGuard.route);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['message'])));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Card(
                elevation: 0,
                color: cs.surfaceContainerHighest,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset('assets/images/logo.png', height: 78),
                      const SizedBox(height: 12),
                      Text('تسجيل الدخول', style: theme.textTheme.titleLarge),
                      const SizedBox(height: 16),
                      Form(
                        key: _form,
                        child: Column(
                          children: [
                            TextFormField(
                              controller: _u,
                              decoration: const InputDecoration(labelText: 'اسم المستخدم'),
                              textInputAction: TextInputAction.next,
                              validator: (v) => (v==null||v.trim().isEmpty) ? 'أدخل اسم المستخدم' : null,
                            ),
                            const SizedBox(height: 10),
                            TextFormField(
                              controller: _p,
                              decoration: InputDecoration(
                                labelText: 'كلمة المرور',
                                suffixIcon: IconButton(
                                  icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off),
                                  onPressed: ()=>setState(()=>_obscure=!_obscure),
                                ),
                              ),
                              obscureText: _obscure,
                              onFieldSubmitted: (_) => _submit(),
                              validator: (v) => (v==null||v.isEmpty) ? 'أدخل كلمة المرور' : null,
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Spacer(),
                                TextButton(
                                  onPressed: ()=> Navigator.of(context).pushNamed(ForgotPasswordScreen.route),
                                  child: const Text('نسيت كلمة المرور؟'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: _loading ? null : _submit,
                                icon: _loading ? const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)) : const Icon(Icons.lock_open),
                                label: const Text('دخول'),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text('© سنام الأمن', style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
