import 'package:flutter/material.dart';

class HomeGuard extends StatelessWidget {
  static const route = '/home';
  const HomeGuard({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('لوحة حارس الأمن')),
        body: const Center(child: Text('مرحبًا بك!')),
      ),
    );
  }
}
